﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form6 : Form
    {
        Random r = new Random();
        int b;
        public Form6()
        {
            InitializeComponent();
           b = r.Next(0, 99);
        }
        int i,k;

        private void button2_Click(object sender, EventArgs e)
        {
            b = r.Next(0, 99);
            k = 0;
            label8.Text = k.ToString();
            i = 0;
            label1.Text = i.ToString();
            i = 100;
            label5.Text = i.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show("請問是否離開遊戲嗎?", "猜數字遊戲", MessageBoxButtons.OKCancel, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            if (r == DialogResult.OK)
            {
                Application.Exit();
            }
        }

        private void Form6_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            i = int.Parse(textBox1.Text);
            if (i==b)
            {
               MessageBox.Show("skr贏了");
            }
            else
            {
                k++;
                label8.Text = k.ToString();
                if (i < b)
                {
                    label1.Text = i.ToString();
                }
                else
                {
                    label5.Text = i.ToString();
                }
            }
        }
    }
}
