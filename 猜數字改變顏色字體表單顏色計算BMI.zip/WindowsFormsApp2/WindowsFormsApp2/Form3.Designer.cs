﻿namespace WindowsFormsApp2
{
    partial class 助教題目不要出太難QQ
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mylabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // mylabel
            // 
            this.mylabel.AutoSize = true;
            this.mylabel.Font = new System.Drawing.Font("新細明體", 72F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.mylabel.Location = new System.Drawing.Point(83, 158);
            this.mylabel.Name = "mylabel";
            this.mylabel.Size = new System.Drawing.Size(628, 120);
            this.mylabel.TabIndex = 0;
            this.mylabel.Text = "Hello World";
            // 
            // 助教題目不要出太難QQ
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.mylabel);
            this.Name = "助教題目不要出太難QQ";
            this.Text = "助教題目不要出太難QQ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label mylabel;
    }
}