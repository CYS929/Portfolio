﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form2 : Form
    {
        Font fontoringin;
        Color colororigin;
        public Form2()
        {
            InitializeComponent();
            fontoringin = label1.Font;
            colororigin = label1.ForeColor;
        }


        int i;
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            i++;
            if (i % 2 != 0) // checkBox1.Checked
            {
                label1.Font = new Font("標楷體", label1.Font.Size );
                    }
            else
            {
                label1.Font = new Font( fontoringin.FontFamily, label1.Font.Size);
            }
        }
        int iii;
        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            iii++;
            if (iii % 2 != 0)
            {
                label1.ForeColor = Color.Red;
            }
            else
            {
                label1.ForeColor = Color.Black;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                label1.Font = new Font(label1.Font.FontFamily,15);
            }
            else
            {
                label1.Font = new Font( fontoringin.FontFamily, fontoringin.Size);
            }
        }
    }
}
